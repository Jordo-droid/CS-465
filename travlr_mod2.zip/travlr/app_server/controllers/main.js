/* GET Homepage */
const index = (req, res) => {
    res.render('index', { titel: 'Travlr Getaways'});
};
module.exports = {
    index
};